package com.example.project;

import androidx.lifecycle.ViewModel;

public class AddItemViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}